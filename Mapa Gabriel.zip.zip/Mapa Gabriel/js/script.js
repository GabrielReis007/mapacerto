$(document).ready(function() {
  console.log('Página carregada.');
});
